library("future.batchtools")
demo("mandelbrot", package = "future", ask = FALSE)
message("\n\nTIPS: Try this demo with for instance plan(batchtools_local).\n")
