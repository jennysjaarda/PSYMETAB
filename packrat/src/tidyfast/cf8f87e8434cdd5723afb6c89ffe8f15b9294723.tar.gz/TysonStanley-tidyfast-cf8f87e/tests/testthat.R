library(testthat)
library(tidyfast)
library(data.table)

test_check("tidyfast")
