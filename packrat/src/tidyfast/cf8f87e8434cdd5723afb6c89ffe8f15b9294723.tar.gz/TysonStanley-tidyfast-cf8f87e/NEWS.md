# tidyfast 0.2.0

* Initial release of `tidyfast`!

