## ----wflow-use-gitlab, eval=FALSE----------------------------------------
#  wflow_use_gitlab(username = "myname", repository = "myproject")

## ----wflow-git-push, eval=FALSE------------------------------------------
#  wflow_git_push()

