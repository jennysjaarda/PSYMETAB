nohup R CMD BATCH tests-separate.R &
