# ndjson

<details>

* Version: 0.7.0
* Source code: https://github.com/cran/ndjson
* URL: http://gitlab.com/hrbrmstr/ndjson
* BugReports: https://gitlab.com/hrbrmstr/ndjson/issues
* Date/Publication: 2018-09-18 09:00:03 UTC
* Number of recursive dependencies: 39

Run `revdep_details(,"ndjson")` for more info

</details>

## Newly broken

*   checking whether the package can be loaded ... ERROR
    ```
    Loading this package had a fatal error status code 1
    Loading log:
    Error: package or namespace load failed for ‘ndjson’:
     object ‘tbl_dt’ is not exported by 'namespace:dtplyr'
    Execution halted
    ```

